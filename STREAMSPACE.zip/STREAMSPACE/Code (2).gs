/**
 * StreamSphere backend (Google Apps Script web app)
 * Matches every request made by the StreamSphere HTML page.
 *
 * SETUP
 * 1. Script Properties (Project Settings): RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET (use TEST keys first).
 * 2. Deploy > Manage deployments > edit > New version (Execute as: Me, Access: Anyone).
 * 3. To make someone a moderator/creator, set the "role" column in the Users tab to
 *    admin, creator or moderator.
 * Tabs are created automatically. Missing columns are added to the right of existing ones,
 * and header names are matched ignoring case/spaces, so your existing tabs keep working.
 */

const SS_ID = '1g9_evTGz3BL7IZ15gnbuxKz03sRsYmHFxdx3lDyVBUA';
const TZ = 'Asia/Kolkata';
const SLOW_MODE_MS = 10000;
const SESSION_DAYS = 30;
const PLAN_DAYS = 30;
const RESERVED_NAMES = ['streamsphere official', 'streamsphere originals', 'creator'];

const PLANS = {
  free:   { name: 'Free',   rank: 0, amount: 0,     downloads: 1 },
  bronze: { name: 'Bronze', rank: 1, amount: 9900,  downloads: 3 },
  silver: { name: 'Silver', rank: 2, amount: 19900, downloads: 10 },
  gold:   { name: 'Gold',   rank: 3, amount: 29900, downloads: 50 }
};

const HEADERS = {
  Comments: ['commentId', 'parentCommentId', 'videoId', 'username', 'email', 'viewerId', 'comment', 'location',
    'showLocation', 'language', 'spoiler', 'gifUrl', 'voiceClipKey', 'timestamp', 'status', 'moderationReason',
    'isPinned', 'editHistory', 'deleted'],
  Users: ['email', 'name', 'salt', 'passwordHash', 'role', 'mobile', 'createdAt'],
  Sessions: ['token', 'email', 'viewerId', 'createdAt', 'expiresAt', 'active'],
  Reactions: ['commentId', 'reactorId', 'reaction', 'username', 'updatedAt'],
  EmojiReactions: ['commentId', 'reactorId', 'emoji', 'updatedAt'],
  Reports: ['commentId', 'reporterId', 'username', 'reason', 'timestamp'],
  TrustedDevices: ['email', 'keyHash', 'createdAt'],
  OtpRequests: ['requestId', 'email', 'codeHash', 'expiresAt', 'attempts', 'used'],
  Notifications: ['notificationId', 'ownerEmail', 'commentId', 'replyCommentId', 'username', 'reply', 'timestamp', 'read'],
  Downloads: ['viewerId', 'email', 'videoId', 'title', 'url', 'authorizedAt', 'dayKey', 'plan', 'count'],
  Payments: ['orderId', 'viewerId', 'email', 'plan', 'amount', 'status', 'paymentId', 'createdAt', 'paidAt', 'expiresAt'],
  VideoReactions: ['videoId', 'reactorId', 'reaction', 'updatedAt']
};

/* ============================ ENTRY POINTS ============================ */

function doGet(e) {
  const p = (e && e.parameter) || {};
  const cb = p.callback;
  try {
    switch (p.action || '') {
      case '':                   return out_(listComments_(p), cb);
      case 'report':             return out_(reportComment_(p), cb);
      case 'checkComment': {
        const msg = moderate_(p.comment || '');
        return out_({ status: 'success', allowed: !msg, message: msg }, cb);
      }
      case 'commentPermissions': return out_(permissions_(p), cb);
      case 'commentReviewQueue': return out_(reviewQueue_(p), cb);
      case 'commentAnalytics':   return out_(analytics_(p), cb);
      case 'commentNotifications': return out_(notifications_(p), cb);
      case 'getPartyState':      return out_(getParty_(p), cb);
      case 'getVideoReaction':   return out_(getVideoReaction_(p), cb);
      case 'setVideoReaction':   return out_(setVideoReaction_(p), cb);
      default: return out_({ status: 'error', message: 'Unknown action.' }, cb);
    }
  } catch (err) {
    return out_({ status: 'error', message: String(err.message || err) }, cb);
  }
}

function doPost(e) {
  const p = (e && e.parameter) || {};
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
    let result;
    switch (p.action || '') {
      case '':
      case 'submitCommentForReview': result = addComment_(p, p.action === 'submitCommentForReview'); break;
      case 'reaction':               result = setReaction_(p); break;
      case 'emojiReaction':          result = setEmoji_(p); break;
      case 'editComment':            result = editComment_(p); break;
      case 'deleteComment':          result = deleteComment_(p); break;
      case 'pinComment':             result = pinComment_(p); break;
      case 'moderateComment':        result = moderateDecision_(p); break;
      case 'markCommentNotificationsRead': result = markNotificationsRead_(p); break;
      case 'registerUser':           result = registerUser_(p); break;
      case 'authenticateUser':       result = authenticateUser_(p); break;
      case 'checkLoginTrust':        result = checkLoginTrust_(p); break;
      case 'requestLoginOtp':        result = requestLoginOtp_(p); break;
      case 'verifyLoginOtp':         result = verifyLoginOtp_(p); break;
      case 'activateCommentSession': result = activateSession_(p); break;
      case 'createRazorpayOrder':    result = createOrder_(p); break;
      case 'verifyRazorpayPayment':  result = verifyPayment_(p); break;
      case 'getDownloadStatus':      result = { status: 'success', plan: planFor_(p.viewerId) }; break;
      case 'getDownloadHistory':     result = downloadHistory_(p); break;
      case 'authorizeDownload':      result = authorizeDownload_(p); break;
      case 'updatePartyState':       result = setParty_(p); break;
      default: result = { status: 'error', message: 'Unknown action.' };
    }
    return out_(result);
  } catch (err) {
    return out_({ status: 'error', message: String(err.message || err) });
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
}

function out_(obj, cb) {
  const json = JSON.stringify(obj);
  if (cb && /^[\w$.]+$/.test(cb)) {
    return ContentService.createTextOutput(cb + '(' + json + ');').setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService.createTextOutput(json).setMimeType(ContentService.MimeType.JSON);
}

/* ============================ SHEET HELPERS ============================ */

const norm_ = s => String(s).toLowerCase().replace(/[\s_]/g, '');
const isTrue_ = v => v === true || String(v).toLowerCase() === 'true';
const str_ = v => (v === null || v === undefined) ? '' : String(v);
const now_ = () => new Date().toISOString();
const uuid_ = () => Utilities.getUuid();

// Stop spreadsheet formula injection from user text.
function safe_(v) {
  if (typeof v === 'string' && /^[=+\-@]/.test(v)) return "'" + v;
  return v;
}

function cols_(name) {
  const ss = SpreadsheetApp.openById(SS_ID);
  let sh = ss.getSheetByName(name);
  const want = HEADERS[name];
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.getRange(1, 1, 1, want.length).setValues([want]);
    sh.setFrozenRows(1);
  } else if (sh.getLastRow() === 0) {
    sh.getRange(1, 1, 1, want.length).setValues([want]);
  }
  let head = sh.getRange(1, 1, 1, Math.max(sh.getLastColumn(), 1)).getValues()[0].map(norm_);
  let n = head.length;
  while (n > 0 && !head[n - 1]) n--;
  head = head.slice(0, n);
  const missing = want.filter(k => head.indexOf(norm_(k)) < 0);
  if (missing.length) {
    sh.getRange(1, n + 1, 1, missing.length).setValues([missing]);
    head = head.concat(missing.map(norm_));
  }
  const idx = {};
  want.forEach(k => { idx[k] = head.indexOf(norm_(k)); });
  return { sh: sh, idx: idx, width: head.length };
}

function table_(name) {
  const c = cols_(name);
  const rows = [];
  const last = c.sh.getLastRow();
  if (last >= 2) {
    const data = c.sh.getRange(2, 1, last - 1, c.width).getValues();
    data.forEach((r, i) => {
      const o = { _row: i + 2 };
      HEADERS[name].forEach(k => {
        const v = r[c.idx[k]];
        o[k] = v instanceof Date ? v.toISOString() : v;
      });
      rows.push(o);
    });
  }
  return { c: c, rows: rows };
}

function add_(name, obj) {
  const c = cols_(name);
  const row = new Array(c.width).fill('');
  Object.keys(obj).forEach(k => { if (c.idx[k] >= 0) row[c.idx[k]] = safe_(obj[k]); });
  c.sh.appendRow(row);
}

function update_(name, rowNum, updates) {
  const c = cols_(name);
  Object.keys(updates).forEach(k => {
    if (c.idx[k] >= 0) c.sh.getRange(rowNum, c.idx[k] + 1).setValue(safe_(updates[k]));
  });
}

/* ============================ CRYPTO / LIMITS ============================ */

const hex_ = bytes => bytes.map(b => ('0' + (b & 255).toString(16)).slice(-2)).join('');
const sha256_ = s => hex_(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, s, Utilities.Charset.UTF_8));
const hmac_ = (msg, key) => hex_(Utilities.computeHmacSha256Signature(msg, key));

function allow_(key, max, ttl) {
  const cache = CacheService.getScriptCache();
  const n = Number(cache.get(key) || 0);
  if (n >= max) return false;
  cache.put(key, String(n + 1), ttl);
  return true;
}

/* ============================ USERS / SESSIONS ============================ */

function userByEmail_(email) {
  email = str_(email).trim().toLowerCase();
  return email ? table_('Users').rows.find(r => str_(r.email).toLowerCase() === email) : null;
}

function sessionEmail_(token, viewerId) {
  if (!token) return '';
  const s = table_('Sessions').rows.find(r => str_(r.token) === str_(token));
  if (!s || !isTrue_(s.active) || new Date(s.expiresAt) < new Date()) return '';
  if (viewerId && s.viewerId && str_(s.viewerId) !== str_(viewerId)) return '';
  return str_(s.email).toLowerCase();
}

function role_(email) {
  const u = userByEmail_(email);
  return u ? str_(u.role).toLowerCase() : '';
}

function permissions_(p) {
  const email = sessionEmail_(p.sessionToken, p.viewerId);
  if (!email) return { status: 'error', message: 'Not signed in.' };
  const r = role_(email);
  return {
    status: 'success',
    canModerate: ['admin', 'creator', 'moderator'].indexOf(r) >= 0,
    canPin: ['admin', 'creator'].indexOf(r) >= 0
  };
}

function requirePerm_(p, pin) {
  const perm = permissions_(p);
  if (perm.status !== 'success' || !(pin ? perm.canPin : perm.canModerate)) throw new Error('Not allowed.');
}

function registerUser_(p) {
  const name = str_(p.name).trim().slice(0, 40);
  const email = str_(p.email).trim().toLowerCase();
  const password = str_(p.password);
  if (!name) return { status: 'error', message: 'Please enter a display name.' };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { status: 'error', message: 'Enter a valid email address.' };
  if (password.length < 8 || (password.match(/\d/g) || []).length < 2 || !/[^A-Za-z0-9]/.test(password)) {
    return { status: 'error', message: 'Password must contain at least 8 characters, 2 numbers, and 1 special character.' };
  }
  if (userByEmail_(email)) return { status: 'error', message: 'An account with this email already exists.' };
  const salt = uuid_();
  add_('Users', { email: email, name: name, salt: salt, passwordHash: sha256_(salt + password), role: 'user', mobile: '', createdAt: now_() });
  return { status: 'success' };
}

function authenticateUser_(p) {
  const email = str_(p.email).trim().toLowerCase();
  if (!allow_('login:' + email, 5, 900)) return { status: 'error', message: 'Too many attempts. Try again in 15 minutes.' };
  const u = userByEmail_(email);
  if (!u || sha256_(str_(u.salt) + str_(p.password)) !== str_(u.passwordHash)) {
    return { status: 'error', message: 'Incorrect email or password.' };
  }
  const token = uuid_() + uuid_();
  const expires = new Date(Date.now() + SESSION_DAYS * 864e5).toISOString();
  // Session stays inactive until the device check / OTP step finishes (activateCommentSession).
  add_('Sessions', { token: token, email: email, viewerId: str_(p.viewerId), createdAt: now_(), expiresAt: expires, active: 'FALSE' });
  return { status: 'success', name: str_(u.name), sessionToken: token };
}

function checkLoginTrust_(p) {
  const email = str_(p.email).trim().toLowerCase();
  const key = sha256_(str_(p.trustedKey));
  const trusted = table_('TrustedDevices').rows.some(r => str_(r.email).toLowerCase() === email && str_(r.keyHash) === key);
  if (trusted) CacheService.getScriptCache().put('ok:' + email, '1', 120);
  return { status: 'success', trusted: trusted };
}

function requestLoginOtp_(p) {
  const email = str_(p.email).trim().toLowerCase();
  if (!userByEmail_(email)) return { status: 'error', message: 'Unable to send OTP.' };
  if (!allow_('otp:' + email, 3, 600)) return { status: 'error', message: 'Too many OTP requests. Try again later.' };
  const code = String(Math.floor(100000 + Math.random() * 900000));
  const requestId = uuid_();
  add_('OtpRequests', {
    requestId: requestId, email: email, codeHash: sha256_(requestId + code),
    expiresAt: new Date(Date.now() + 600000).toISOString(), attempts: 0, used: 'FALSE'
  });
  MailApp.sendEmail(email, 'Your StreamSphere verification code',
    'Your verification code is ' + code + '. It expires in 10 minutes. If this was not you, ignore this email.');
  const masked = email.replace(/^(.).*(@.*)$/, '$1***$2');
  return { status: 'otp_sent', destination: masked, requestId: requestId };
}

function verifyLoginOtp_(p) {
  const rec = table_('OtpRequests').rows.find(r => str_(r.requestId) === str_(p.requestId));
  if (!rec || isTrue_(rec.used) || new Date(rec.expiresAt) < new Date()) return { status: 'error', message: 'Code expired. Request a new one.' };
  const attempts = Number(rec.attempts || 0) + 1;
  update_('OtpRequests', rec._row, { attempts: attempts });
  if (attempts > 5) return { status: 'error', message: 'Too many incorrect attempts.' };
  if (sha256_(str_(rec.requestId) + str_(p.code).trim()) !== str_(rec.codeHash)) return { status: 'error', message: 'Incorrect verification code.' };
  update_('OtpRequests', rec._row, { used: 'TRUE' });
  add_('TrustedDevices', { email: str_(rec.email), keyHash: sha256_(str_(p.trustedKey)), createdAt: now_() });
  CacheService.getScriptCache().put('ok:' + str_(rec.email).toLowerCase(), '1', 120);
  return { status: 'verified' };
}

function activateSession_(p) {
  const s = table_('Sessions').rows.find(r => str_(r.token) === str_(p.sessionToken));
  if (!s || new Date(s.expiresAt) < new Date()) return { status: 'error', message: 'Session expired. Please log in again.' };
  if (!CacheService.getScriptCache().get('ok:' + str_(s.email).toLowerCase())) {
    return { status: 'error', message: 'Device verification required.' };
  }
  update_('Sessions', s._row, { active: 'TRUE', viewerId: str_(p.viewerId) });
  return { status: 'success' };
}

/* ============================ MODERATION ============================ */

function moderate_(text) {
  const n = str_(text).toLowerCase().replace(/\s+/g, ' ').trim();
  const bad = ['fuck', 'shit', 'bitch', 'asshole', 'bastard', 'cunt'];
  if (bad.some(w => new RegExp('(^|[^a-z])' + w + '([^a-z]|$)', 'i').test(n))) return 'Please remove abusive language before posting.';
  if (/(https?:\/\/|www\.|[a-z0-9-]+\.(com|net|org|xyz|tk)\b)/i.test(n)) return 'Links are not allowed in comments.';
  if (/(free money|buy now|click here|subscribe now|follow me|promo code|make money)/i.test(n)) return 'This comment looks like spam.';
  const vis = n.replace(/\s/g, '');
  const special = vis.replace(/[\p{L}\p{N}]/gu, '');
  if (vis.length >= 4 && special.length / vis.length >= 0.7) return 'Comments made mostly of repeated special characters are not allowed.';
  if (/(.)\1{5,}/u.test(vis) || /(\b\w+\b)(?:\s+\1){3,}/iu.test(n)) return 'Please avoid repeated characters or repeated words.';
  if (n.length > 5000) return 'Comments must be 5,000 characters or fewer.';
  return '';
}

function trustedGif_(url) {
  const m = str_(url).match(/^https:\/\/([^\/]+)\/[^?#]*\.gif(?:[?#].*)?$/i);
  return !!m && ['media.giphy.com', 'i.giphy.com', 'media.tenor.com'].indexOf(m[1].toLowerCase()) >= 0;
}

/* ============================ COMMENTS ============================ */

function ownerOf_(row, p, email) {
  return (!!p.viewerId && str_(row.viewerId) === str_(p.viewerId)) ||
         (!!email && str_(row.email).toLowerCase() === email);
}

function findComment_(id) {
  return table_('Comments').rows.find(r => str_(r.commentId) === str_(id) && !isTrue_(r.deleted));
}

function addComment_(p, forceReview) {
  const email = sessionEmail_(p.sessionToken, p.viewerId);
  const commentId = str_(p.commentId) || uuid_();
  if (findComment_(commentId)) return { status: 'success' };

  let comment = str_(p.comment).trim();
  const gifUrl = trustedGif_(p.gifUrl) ? str_(p.gifUrl) : '';
  const voice = str_(p.voiceClipKey);
  if (!comment && !gifUrl && !voice) throw new Error('Comment is empty.');
  if (comment.length > 5000) throw new Error('Comments must be 5,000 characters or fewer.');

  const all = table_('Comments').rows;
  const ownerLast = all.filter(r => ownerOf_(r, p, email)).map(r => new Date(r.timestamp).getTime() || 0);
  if (ownerLast.length && Date.now() - Math.max.apply(null, ownerLast) < SLOW_MODE_MS) throw new Error('Slow mode is on.');

  let username = str_(p.username).trim().slice(0, 40) || 'Guest User';
  if (RESERVED_NAMES.indexOf(username.toLowerCase()) >= 0 && ['admin', 'creator'].indexOf(role_(email)) < 0) username = 'Guest User';

  const reason = moderate_(comment) || (forceReview ? 'Held for moderator review' : '');
  add_('Comments', {
    commentId: commentId, parentCommentId: str_(p.parentCommentId), videoId: str_(p.videoId) || 'celestial-anomaly-ep4',
    username: username, email: email, viewerId: str_(p.viewerId), comment: comment || (voice ? '[Voice comment]' : '[GIF]'),
    location: isTrue_(p.showLocation) ? str_(p.location).slice(0, 80) : '', showLocation: isTrue_(p.showLocation) ? 'TRUE' : 'FALSE',
    language: str_(p.language) || 'English', spoiler: isTrue_(p.spoiler) ? 'TRUE' : 'FALSE',
    gifUrl: gifUrl, voiceClipKey: voice, timestamp: now_(), status: reason ? 'Pending Review' : 'Approved',
    moderationReason: reason, isPinned: 'FALSE', editHistory: '[]', deleted: 'FALSE'
  });

  if (p.parentCommentId && !reason) {
    const parent = findComment_(p.parentCommentId);
    const parentEmail = parent ? str_(parent.email).toLowerCase() : '';
    if (parentEmail && parentEmail !== email) {
      add_('Notifications', {
        notificationId: uuid_(), ownerEmail: parentEmail, commentId: str_(p.parentCommentId), replyCommentId: commentId,
        username: username, reply: comment.slice(0, 120), timestamp: now_(), read: 'FALSE'
      });
    }
  }
  return { status: 'success' };
}

function listComments_(p) {
  const email = sessionEmail_(p.sessionToken, p.viewerId);
  const canModerate = ['admin', 'creator', 'moderator'].indexOf(role_(email)) >= 0;

  const likes = {}, dislikes = {}, mine = {};
  table_('Reactions').rows.forEach(r => {
    const id = str_(r.commentId);
    if (r.reaction === 'like') likes[id] = (likes[id] || 0) + 1;
    if (r.reaction === 'dislike') dislikes[id] = (dislikes[id] || 0) + 1;
    if (r.reaction && str_(r.reactorId) === str_(p.reactorId)) mine[id] = str_(r.reaction);
  });
  const emojiCounts = {}, myEmoji = {};
  table_('EmojiReactions').rows.forEach(r => {
    if (!r.emoji) return;
    const id = str_(r.commentId);
    emojiCounts[id] = emojiCounts[id] || {};
    emojiCounts[id][r.emoji] = (emojiCounts[id][r.emoji] || 0) + 1;
    if (str_(r.reactorId) === str_(p.emojiReactorId)) myEmoji[id] = str_(r.emoji);
  });

  const comments = table_('Comments').rows
    .filter(r => r.commentId && !isTrue_(r.deleted) && ['Deleted', 'Rejected'].indexOf(str_(r.status)) < 0)
    .map(r => ({ r: r, owner: ownerOf_(r, p, email), status: str_(r.status) || 'Approved' }))
    .filter(x => x.status !== 'Pending Review' || x.owner || canModerate)
    .sort((a, b) => new Date(b.r.timestamp) - new Date(a.r.timestamp))
    .map(x => {
      const r = x.r, id = str_(r.commentId);
      let history = [];
      try { history = JSON.parse(str_(r.editHistory) || '[]'); } catch (e) {}
      return {
        commentId: id, parentCommentId: str_(r.parentCommentId), username: str_(r.username), comment: str_(r.comment),
        timestamp: str_(r.timestamp), location: isTrue_(r.showLocation) ? str_(r.location) : '',
        likes: likes[id] || 0, dislikes: dislikes[id] || 0, viewerReaction: mine[id] || '',
        isOwner: x.owner, isPinned: isTrue_(r.isPinned), moderationStatus: x.status, moderationReason: str_(r.moderationReason),
        emojiReactionCounts: emojiCounts[id] || {}, viewerEmoji: myEmoji[id] || '',
        gifUrl: trustedGif_(r.gifUrl) ? str_(r.gifUrl) : '', voiceClipKey: str_(r.voiceClipKey),
        spoiler: isTrue_(r.spoiler), language: str_(r.language), editHistory: history
      };
    });
  return { status: 'success', comments: comments };
}

function setReaction_(p) {
  const id = str_(p.commentId), reactor = str_(p.reactorId);
  if (!id || !reactor) throw new Error('Missing data.');
  const reaction = ['like', 'dislike'].indexOf(p.reaction) >= 0 ? p.reaction : '';
  const row = table_('Reactions').rows.find(r => str_(r.commentId) === id && str_(r.reactorId) === reactor);
  if (row) update_('Reactions', row._row, { reaction: reaction, updatedAt: now_() });
  else if (reaction) add_('Reactions', { commentId: id, reactorId: reactor, reaction: reaction, username: str_(p.username), updatedAt: now_() });
  return { status: 'success' };
}

function getVideoReaction_(p) {
  const videoId = str_(p.videoId).trim(), reactorId = str_(p.reactorId).trim();
  if (!videoId || !reactorId) throw new Error('Missing data.');

  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    return videoReactionState_(videoId, reactorId);
  } finally {
    lock.releaseLock();
  }
}

function setVideoReaction_(p) {
  const videoId = str_(p.videoId).trim(), reactorId = str_(p.reactorId).trim();
  if (!videoId || !reactorId) throw new Error('Missing data.');
  const reaction = ['like', 'dislike'].indexOf(p.reaction) >= 0 ? p.reaction : '';

  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const row = table_('VideoReactions').rows.find(r =>
      str_(r.videoId) === videoId && str_(r.reactorId) === reactorId
    );
    if (row) {
      update_('VideoReactions', row._row, { reaction: reaction, updatedAt: now_() });
    } else if (reaction) {
      add_('VideoReactions', {
        videoId: videoId, reactorId: reactorId, reaction: reaction, updatedAt: now_()
      });
    }
    return videoReactionState_(videoId, reactorId);
  } finally {
    lock.releaseLock();
  }
}

function videoReactionState_(videoId, reactorId) {
  const state = { status: 'success', likes: 0, dislikes: 0, viewerReaction: '' };
  table_('VideoReactions').rows.forEach(row => {
    if (str_(row.videoId) !== videoId) return;
    if (row.reaction === 'like') state.likes++;
    if (row.reaction === 'dislike') state.dislikes++;
    if (str_(row.reactorId) === reactorId) state.viewerReaction = str_(row.reaction);
  });
  return state;
}

function setEmoji_(p) {
  const email = sessionEmail_(p.sessionToken, p.viewerId);
  const reactor = email ? 'email:' + email : 'viewer:' + str_(p.viewerId);
  const id = str_(p.commentId), emoji = str_(p.emoji);
  if (['❤️', '😂', '😮', '😢', '🔥'].indexOf(emoji) < 0 || !id) throw new Error('Invalid reaction.');
  const row = table_('EmojiReactions').rows.find(r => str_(r.commentId) === id && str_(r.reactorId) === reactor);
  if (row) update_('EmojiReactions', row._row, { emoji: str_(row.emoji) === emoji ? '' : emoji, updatedAt: now_() });
  else add_('EmojiReactions', { commentId: id, reactorId: reactor, emoji: emoji, updatedAt: now_() });
  return { status: 'success' };
}

function requireOwner_(p) {
  const email = sessionEmail_(p.sessionToken, p.viewerId);
  const c = findComment_(p.commentId);
  if (!c || !ownerOf_(c, p, email)) throw new Error('Not allowed.');
  return c;
}

function editComment_(p) {
  const c = requireOwner_(p);
  const text = str_(p.comment).trim();
  if (!text || text.length > 5000) throw new Error('Invalid comment.');
  const flag = moderate_(text);
  if (flag) throw new Error(flag);
  let history = [];
  try { history = JSON.parse(str_(c.editHistory) || '[]'); } catch (e) {}
  history.push({ text: str_(c.comment), editedAt: now_() });
  update_('Comments', c._row, { comment: text, status: 'Approved', moderationReason: '', editHistory: JSON.stringify(history.slice(-20)) });
  return { status: 'success' };
}

function deleteComment_(p) {
  const c = requireOwner_(p);
  update_('Comments', c._row, { deleted: 'TRUE', status: 'Deleted' });
  return { status: 'success' };
}

function pinComment_(p) {
  requirePerm_(p, true);
  const pin = isTrue_(p.pinned);
  table_('Comments').rows.filter(r => isTrue_(r.isPinned)).forEach(r => update_('Comments', r._row, { isPinned: 'FALSE' }));
  const c = findComment_(p.commentId);
  if (c && pin) update_('Comments', c._row, { isPinned: 'TRUE' });
  return { status: 'success' };
}

function moderateDecision_(p) {
  requirePerm_(p, false);
  const c = findComment_(p.commentId);
  if (!c) throw new Error('Comment not found.');
  if (p.decision === 'approve') update_('Comments', c._row, { status: 'Approved', moderationReason: '' });
  else if (p.decision === 'reject') update_('Comments', c._row, { status: 'Rejected' });
  return { status: 'success' };
}

function reviewQueue_(p) {
  const perm = permissions_(p);
  if (perm.status !== 'success' || !perm.canModerate) return { status: 'error', message: 'Not allowed.' };
  const items = table_('Comments').rows
    .filter(r => str_(r.status) === 'Pending Review' && !isTrue_(r.deleted))
    .map(r => ({ commentId: str_(r.commentId), username: str_(r.username), comment: str_(r.comment), reason: str_(r.moderationReason) }));
  return { status: 'success', items: items };
}

function analytics_(p) {
  const perm = permissions_(p);
  if (perm.status !== 'success' || !perm.canModerate) return { status: 'error', message: 'Not allowed.' };
  const comments = table_('Comments').rows.filter(r => r.commentId && !isTrue_(r.deleted));
  return {
    status: 'success',
    totalComments: comments.length,
    totalLikes: table_('Reactions').rows.filter(r => r.reaction === 'like').length,
    totalReports: table_('Reports').rows.length,
    flaggedComments: comments.filter(r => str_(r.status) === 'Pending Review').length
  };
}

function reportComment_(p) {
  const id = str_(p.commentId), reporter = str_(p.reporterId);
  if (!id || !reporter) return { status: 'error', message: 'Missing data.' };
  const reports = table_('Reports').rows.filter(r => str_(r.commentId) === id);
  if (!reports.some(r => str_(r.reporterId) === reporter)) {
    add_('Reports', { commentId: id, reporterId: reporter, username: str_(p.username), reason: str_(p.reason).slice(0, 500), timestamp: now_() });
    if (reports.length + 1 >= 3) {
      const c = findComment_(id);
      if (c && str_(c.status) !== 'Rejected') update_('Comments', c._row, { status: 'Pending Review', moderationReason: 'Reported by multiple viewers' });
    }
  }
  return { status: 'success' };
}

function notifications_(p) {
  const email = sessionEmail_(p.sessionToken, p.viewerId);
  if (!email) return { status: 'error', message: 'Not signed in.' };
  const items = table_('Notifications').rows
    .filter(r => str_(r.ownerEmail).toLowerCase() === email)
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)).slice(0, 50)
    .map(r => ({
      notificationId: str_(r.notificationId), replyCommentId: str_(r.replyCommentId), commentId: str_(r.commentId),
      timestamp: str_(r.timestamp), read: isTrue_(r.read), username: str_(r.username), reply: str_(r.reply)
    }));
  return { status: 'success', items: items };
}

function markNotificationsRead_(p) {
  const email = sessionEmail_(p.sessionToken, p.viewerId);
  if (!email) return { status: 'error', message: 'Not signed in.' };
  table_('Notifications').rows
    .filter(r => str_(r.ownerEmail).toLowerCase() === email && !isTrue_(r.read))
    .forEach(r => update_('Notifications', r._row, { read: 'TRUE' }));
  return { status: 'success' };
}

/* ============================ PLANS / PAYMENTS / DOWNLOADS ============================ */

function emailsForViewer_(viewerId) {
  const set = {};
  if (!viewerId) return set;
  table_('Sessions').rows.forEach(s => {
    if (isTrue_(s.active) && str_(s.viewerId) === str_(viewerId)) set[str_(s.email).toLowerCase()] = true;
  });
  return set;
}

function planFor_(viewerId) {
  const emails = emailsForViewer_(viewerId);
  const now = new Date();
  let best = 'free';
  table_('Payments').rows.forEach(r => {
    if (str_(r.status) !== 'paid' || new Date(r.expiresAt) < now || !PLANS[str_(r.plan)]) return;
    const match = str_(r.viewerId) === str_(viewerId) || emails[str_(r.email).toLowerCase()];
    if (match && PLANS[str_(r.plan)].rank > PLANS[best].rank) best = str_(r.plan);
  });
  return best;
}

function createOrder_(p) {
  const plan = PLANS[p.plan];
  if (!plan || plan.amount <= 0) return { status: 'error', message: 'Invalid plan.' };
  const props = PropertiesService.getScriptProperties();
  const keyId = props.getProperty('RAZORPAY_KEY_ID'), secret = props.getProperty('RAZORPAY_KEY_SECRET');
  if (!keyId || !secret) return { status: 'error', message: 'Payments are not configured.' };
  const res = UrlFetchApp.fetch('https://api.razorpay.com/v1/orders', {
    method: 'post', contentType: 'application/json', muteHttpExceptions: true,
    headers: { Authorization: 'Basic ' + Utilities.base64Encode(keyId + ':' + secret) },
    payload: JSON.stringify({ amount: plan.amount, currency: 'INR', receipt: 'ss_' + Date.now(), notes: { plan: p.plan } })
  });
  const order = JSON.parse(res.getContentText() || '{}');
  if (res.getResponseCode() >= 300 || !order.id) return { status: 'error', message: 'Unable to create payment order.' };
  add_('Payments', { orderId: order.id, viewerId: str_(p.viewerId), email: '', plan: p.plan, amount: plan.amount, status: 'created', createdAt: now_() });
  return { status: 'success', keyId: keyId, amount: plan.amount, currency: 'INR', orderId: order.id, planName: plan.name };
}

function verifyPayment_(p) {
  const secret = PropertiesService.getScriptProperties().getProperty('RAZORPAY_KEY_SECRET');
  const rec = table_('Payments').rows.find(r => str_(r.orderId) === str_(p.orderId));
  if (!secret || !rec || str_(rec.viewerId) !== str_(p.viewerId) || str_(rec.plan) !== str_(p.plan)) {
    return { status: 'error', message: 'Payment verification failed.' };
  }
  if (str_(rec.status) === 'paid') return { status: 'success', plan: str_(rec.plan), planName: PLANS[str_(rec.plan)].name };
  if (hmac_(str_(p.orderId) + '|' + str_(p.paymentId), secret) !== str_(p.signature)) {
    update_('Payments', rec._row, { status: 'failed' });
    return { status: 'error', message: 'Payment signature mismatch.' };
  }
  update_('Payments', rec._row, {
    status: 'paid', paymentId: str_(p.paymentId), email: str_(p.email).trim().toLowerCase(),
    paidAt: now_(), expiresAt: new Date(Date.now() + PLAN_DAYS * 864e5).toISOString()
  });
  return { status: 'success', plan: str_(rec.plan), planName: PLANS[str_(rec.plan)].name };
}

function downloadRowsFor_(viewerId) {
  const emails = emailsForViewer_(viewerId);
  return table_('Downloads').rows.filter(r => str_(r.viewerId) === str_(viewerId) || emails[str_(r.email).toLowerCase()]);
}

function authorizeDownload_(p) {
  if (!p.viewerId) return { status: 'denied', message: 'Unable to identify this device.' };
  const plan = planFor_(p.viewerId), info = PLANS[plan];
  const today = Utilities.formatDate(new Date(), TZ, 'yyyyMMdd');
  const used = downloadRowsFor_(p.viewerId).filter(r => str_(r.dayKey) === today).length;
  if (used >= info.downloads) {
    return {
      status: 'denied', plan: plan,
      message: 'Your ' + info.name + ' plan allows ' + info.downloads + ' download' + (info.downloads === 1 ? '' : 's') +
               ' per day. Upgrade your plan for more.'
    };
  }
  const emails = Object.keys(emailsForViewer_(p.viewerId));
  add_('Downloads', {
    viewerId: str_(p.viewerId), email: emails[0] || '', videoId: str_(p.videoId), title: str_(p.videoTitle).slice(0, 200),
    url: str_(p.videoUrl).slice(0, 500), authorizedAt: now_(), dayKey: today, plan: plan, count: used + 1
  });
  return { status: 'authorized', plan: plan };
}

function downloadHistory_(p) {
  const history = downloadRowsFor_(p.viewerId)
    .sort((a, b) => new Date(a.authorizedAt) - new Date(b.authorizedAt)).slice(-50)
    .map(r => ({
      title: str_(r.title), plan: str_(r.plan), count: Number(r.count) || 1, authorizedAt: str_(r.authorizedAt),
      date: Utilities.formatDate(new Date(r.authorizedAt), TZ, 'dd MMM yyyy')
    }));
  return { status: 'success', history: history };
}

/* ============================ WATCH PARTY ============================ */
// Held in CacheService (the page polls every second, far too often for a sheet).

function setParty_(p) {
  const room = str_(p.roomId).replace(/[^A-Za-z0-9]/g, '').slice(0, 12);
  if (!room) return { status: 'error', message: 'Missing room.' };
  const state = { senderId: str_(p.senderId), paused: isTrue_(p.paused), time: Number(p.time) || 0, updatedAt: Date.now() };
  CacheService.getScriptCache().put('party:' + room, JSON.stringify(state), 21600);
  return { status: 'success' };
}

function getParty_(p) {
  const room = str_(p.roomId).replace(/[^A-Za-z0-9]/g, '').slice(0, 12);
  const raw = room ? CacheService.getScriptCache().get('party:' + room) : null;
  return { status: 'success', state: raw ? JSON.parse(raw) : null };
}