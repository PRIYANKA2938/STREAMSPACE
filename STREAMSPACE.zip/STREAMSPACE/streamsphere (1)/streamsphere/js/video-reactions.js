let videoReactionCounts = { likes: 0, dislikes: 0 };

function currentVideoId() {
  return document.getElementById('videoId')?.value || 'celestial-anomaly-ep4';
}

function currentVideoReactionKey() {
  return 'streamsphereVideoReaction:' + currentVideoId();
}

function updateVideoReactionButtons(reaction, counts = videoReactionCounts) {
  videoReactionCounts = {
    likes: Number(counts.likes) || 0,
    dislikes: Number(counts.dislikes) || 0
  };
  document.querySelectorAll('.video-reaction').forEach(button => {
    const isActive = button.dataset.videoReaction === reaction;
    button.classList.toggle('active', isActive);
    button.setAttribute('aria-pressed', String(isActive));
    const count = button.querySelector('.video-reaction-count');
    const total = button.dataset.videoReaction === 'like' ? videoReactionCounts.likes : videoReactionCounts.dislikes;
    if (count) count.textContent = total.toLocaleString();
    button.setAttribute('aria-label', (button.dataset.videoReaction === 'like' ? 'Like video, ' : 'Dislike video, ') + total.toLocaleString());
  });
}

function loadVideoReactionState() {
  const videoId = currentVideoId();
  const key = currentVideoReactionKey();
  const savedReaction = localStorage.getItem(key) || '';
  updateVideoReactionButtons(savedReaction, { likes: 0, dislikes: 0 });
  requestCommentJsonp('getVideoReaction', { videoId, reactorId: getViewerId() }).then(response => {
    if (response.status !== 'success') throw new Error(response.message || 'Unable to load video reactions.');
    const migratedReaction = !response.viewerReaction && savedReaction ? savedReaction : '';
    if (migratedReaction) {
      return requestCommentJsonp('setVideoReaction', {
        videoId,
        reactorId: getViewerId(),
        reaction: migratedReaction
      }).then(mutation => {
        if (mutation.status !== 'success') throw new Error(mutation.message || 'Unable to save the previous video reaction.');
        return mutation;
      }).catch(error => {
        console.error('Unable to migrate video reaction:', error);
        return response;
      });
    }
    return response;
  }).then(response => {
    const viewerReaction = response.viewerReaction || '';
    localStorage.setItem(key, viewerReaction);
    if (currentVideoId() !== videoId) return;
    updateVideoReactionButtons(viewerReaction, response);
    updateLikedVideoHistory(viewerReaction === 'like');
  }).catch(error => console.error('Unable to load video reactions:', error));
}

document.querySelectorAll('.video-reaction').forEach(button => {
  button.addEventListener('click', function() {
    if ([...document.querySelectorAll('.video-reaction')].some(item => item.disabled)) return;
    const nextReaction = this.dataset.videoReaction;
    const key = currentVideoReactionKey();
    const previousReaction = localStorage.getItem(key) || '';
    const nextState = previousReaction === nextReaction ? '' : nextReaction;
    const previousCounts = { ...videoReactionCounts };
    const nextCounts = { ...previousCounts };
    if (previousReaction === 'like') nextCounts.likes = Math.max(0, nextCounts.likes - 1);
    if (previousReaction === 'dislike') nextCounts.dislikes = Math.max(0, nextCounts.dislikes - 1);
    if (nextState === 'like') nextCounts.likes += 1;
    if (nextState === 'dislike') nextCounts.dislikes += 1;
    document.querySelectorAll('.video-reaction').forEach(item => { item.disabled = true; });
    localStorage.setItem(key, nextState);
    updateVideoReactionButtons(nextState, nextCounts);
    updateLikedVideoHistory(nextState === 'like');
    requestCommentJsonp('setVideoReaction', {
      videoId: currentVideoId(),
      reactorId: getViewerId(),
      reaction: nextState
    }).then(response => {
      if (response.status !== 'success') throw new Error(response.message || 'Unable to save video reaction.');
      const savedReaction = response.viewerReaction || '';
      localStorage.setItem(key, savedReaction);
      updateVideoReactionButtons(savedReaction, response);
      updateLikedVideoHistory(savedReaction === 'like');
    }).catch(error => {
      localStorage.setItem(key, previousReaction);
      updateVideoReactionButtons(previousReaction, previousCounts);
      updateLikedVideoHistory(previousReaction === 'like');
      console.error('Video reaction error:', error);
    }).finally(() => {
      document.querySelectorAll('.video-reaction').forEach(item => { item.disabled = false; });
    });
  });
});

loadVideoReactionState();
