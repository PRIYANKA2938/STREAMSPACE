function updateSaveLabel(button, isSaved) {
  const textNode = Array.from(button.childNodes).find(node => node.nodeType === Node.TEXT_NODE && node.textContent.trim());
  if (textNode) textNode.textContent = isSaved ? ' Saved' : ' Save';
  button.setAttribute('aria-label', isSaved ? 'Remove video from saved items' : 'Save this video');
}

function toggleSavedVideo(button) {
  const isSaved = localStorage.getItem(savedVideoKey) === 'true';
  const nextSavedState = !isSaved;
  localStorage.setItem(savedVideoKey, String(nextSavedState));
  document.querySelectorAll('.save-video-action, [data-video-action="save"]').forEach(saveButton => updateSaveLabel(saveButton, nextSavedState));
}

async function shareVideo() {
  const shareData = { title: document.title, text: 'The Celestial Anomaly - Episode 4', url: window.location.href };
  try {
    if (navigator.share) {
      await navigator.share(shareData);
    } else if (navigator.clipboard) {
      await navigator.clipboard.writeText(window.location.href);
      alert('Video link copied to clipboard.');
    } else {
      prompt('Copy this video link:', window.location.href);
    }
  } catch (error) {
    if (error.name !== 'AbortError') console.error('Unable to share video:', error);
  }
}

document.querySelector('.share-video-action').addEventListener('click', shareVideo);
document.querySelector('.save-video-action').addEventListener('click', function() {
  toggleSavedVideo(this);
});
const initiallySaved = localStorage.getItem(savedVideoKey) === 'true';
document.querySelectorAll('.save-video-action, [data-video-action="save"]').forEach(saveButton => updateSaveLabel(saveButton, initiallySaved));

async function downloadVideo() {
  if (!videoDownloadUrl) {
    alert('Video download is not configured for this title yet.');
    return;
  }
  try {
    const authorizationResponse = await fetch(document.getElementById('commentForm').action, {
      method: 'POST',
      body: new URLSearchParams({
        action: 'authorizeDownload',
        viewerId: getViewerId(),
        videoId: 'celestial-anomaly-ep4',
        videoTitle: 'The Celestial Anomaly - Episode 4',
        videoUrl: videoDownloadUrl
      })
    });
    const authorization = await authorizationResponse.json();
    if (authorization.status !== 'authorized') {
      alert(authorization.message || 'Only one video download is allowed per day.');
      return;
    }
    profilePlan.value = authorization.plan;
    localStorage.setItem(profilePlanKey, authorization.plan);
    const response = await fetch(videoDownloadUrl);
    if (!response.ok) throw new Error('Download request failed');
    const downloadUrl = URL.createObjectURL(await response.blob());
    const downloadLink = document.createElement('a');
    downloadLink.href = downloadUrl;
    downloadLink.download = 'celestial-anomaly-episode-4.mp4';
    document.body.appendChild(downloadLink);
    downloadLink.click();
    downloadLink.remove();
    URL.revokeObjectURL(downloadUrl);
    recordProfileDownload();
  } catch (error) {
    console.error('Unable to download video:', error);
    alert('Download authorization or video download failed. Please try again.');
  }
}

document.querySelector('.download-video-action').addEventListener('click', downloadVideo);
