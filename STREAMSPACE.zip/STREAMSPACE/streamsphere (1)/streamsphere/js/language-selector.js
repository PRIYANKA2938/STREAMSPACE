// Language selector (demo)
document.querySelector('.lang-select').addEventListener('click', function(e) {
  e.preventDefault();
  const lang = prompt('Select language:\nEnglish\nTamil\nHindi\nSpanish', 'English');
  if (lang) {
    this.textContent = '🌐 ' + lang + ' ';
    const svg = document.createElement('svg');
    svg.setAttribute('width', '6.7');
    svg.setAttribute('height', '3.3');
    svg.setAttribute('viewBox', '0 0 6.7 3.3');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'currentColor');
    svg.setAttribute('stroke-width', '1');
    svg.innerHTML = '<polyline points="1 1 3.35 2.65 5.7 1"></polyline>';
    this.appendChild(svg);
    document.getElementById('language').value = lang;
  }
});
