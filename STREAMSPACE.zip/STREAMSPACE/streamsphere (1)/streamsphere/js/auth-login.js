async function postLoginRequest(action, values) {
  const response = await fetch(document.getElementById('commentForm').action, {
    method: 'POST',
    body: new URLSearchParams({ action, ...values })
  });
  if (!response.ok) throw new Error('Login verification request failed');
  return response.json();
}

async function completeLogin(displayName, email, mobile, location, sessionToken) {
  const trustedKey = getDeviceTrustKey(location);
  const trustStatus = await postLoginRequest('checkLoginTrust', { email, mobile, trustedKey });
  if (!trustStatus.trusted) {
    const otpResponse = await postLoginRequest('requestLoginOtp', { email, mobile, trustedKey });
    if (otpResponse.status !== 'otp_sent') throw new Error(otpResponse.message || 'Unable to send OTP');
    const code = prompt('Enter the verification code sent to ' + otpResponse.destination + ':');
    if (!code) return false;
    const verification = await postLoginRequest('verifyLoginOtp', { requestId: otpResponse.requestId, code, trustedKey });
    if (verification.status !== 'verified') throw new Error(verification.message || 'OTP verification failed');
  }
  const activeSession = await postLoginRequest('activateCommentSession', { viewerId: getViewerId(), sessionToken });
  if (activeSession.status !== 'success') throw new Error(activeSession.message || 'Unable to activate login session.');
  localStorage.setItem('streamsphereName', displayName);
  localStorage.setItem('streamsphereEmail', email);
  localStorage.setItem('streamsphereAuthToken', sessionToken);
  localStorage.setItem('streamsphereMobile', mobile);
  localStorage.setItem('streamsphereLocation', location);
  document.getElementById('username').value = displayName;
  document.getElementById('email').value = email;
  if (!localStorage.getItem('streamsphereTheme')) applyLoginTheme();
  updatePersonalizedExperience();
  loadCommentModerationPermissions();
  loadServerCommentNotifications();
  return true;
}

document.getElementById('loginButton').addEventListener('click', () => {
  loginStatus.textContent = '';
  document.getElementById('loginEmail').value = localStorage.getItem('streamsphereEmail') || '';
  document.getElementById('loginPassword').value = '';
  if (typeof loginDialog.showModal === 'function') loginDialog.showModal();
  else loginDialog.classList.add('is-open');
});
document.getElementById('cancelLogin').addEventListener('click', () => {
  if (loginDialog.open) loginDialog.close();
  loginDialog.classList.remove('is-open');
});
loginForm.addEventListener('submit', async event => {
  event.preventDefault();
  const email = document.getElementById('loginEmail').value.trim().toLowerCase();
  const password = document.getElementById('loginPassword').value;
  const location = localStorage.getItem('streamsphereLocation') || '';
  const submitButton = loginForm.querySelector('[type="submit"]');
  submitButton.disabled = true;
  loginStatus.textContent = 'Checking your account...';
  try {
    const authentication = await postLoginRequest('authenticateUser', { email, password, viewerId: getViewerId() });
    if (authentication.status !== 'success') throw new Error(authentication.message || 'Incorrect email or password.');
    const verified = await completeLogin(authentication.name || 'Guest User', email, '', location, authentication.sessionToken);
    if (verified) {
      loginStatus.textContent = 'Login successful. Welcome, ' + (authentication.name || 'Guest User') + '.';
      loginForm.reset();
      setTimeout(() => { if (loginDialog.open) loginDialog.close(); }, 1800);
    }
  } catch (error) {
    loginStatus.textContent = error.message || 'Login failed.';
  } finally {
    submitButton.disabled = false;
  }
});
