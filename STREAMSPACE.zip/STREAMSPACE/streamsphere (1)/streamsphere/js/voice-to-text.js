const voiceToTextButton = document.getElementById('voiceToTextButton');
let speechRecognition = null;
let dictationActive = false;
let dictatedText = '';
let dictationPrefix = '';
let dictationSuffix = '';
voiceToTextButton.addEventListener('click', () => {
  if (speechRecognition && dictationActive) {
    dictationActive = false;
    voiceCommentStatus.textContent = 'Finishing dictation...';
    speechRecognition.stop();
    return;
  }
  speechRecognition = null;
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition) {
    voiceCommentStatus.textContent = 'Voice to text is not supported in this browser.';
    return;
  }
  const languageCode = { English: 'en-US', Tamil: 'ta-IN', Hindi: 'hi-IN', Spanish: 'es-ES' }[document.getElementById('language').value] || 'en-US';
  const selectionStart = commentTextInput.selectionStart ?? commentTextInput.value.length;
  const selectionEnd = commentTextInput.selectionEnd ?? selectionStart;
  dictationPrefix = commentTextInput.value.slice(0, selectionStart);
  dictationSuffix = commentTextInput.value.slice(selectionEnd);
  const recognition = new Recognition();
  speechRecognition = recognition;
  recognition.lang = languageCode;
  recognition.continuous = true;
  recognition.interimResults = true;
  dictationActive = true;
  dictatedText = '';
  recognition.onresult = event => {
    if (speechRecognition !== recognition) return;
    let interimText = '';
    for (let index = event.resultIndex; index < event.results.length; index += 1) {
      const transcript = event.results[index][0].transcript.trim();
      if (event.results[index].isFinal) dictatedText += (dictatedText ? ' ' : '') + transcript;
      else interimText += transcript;
    }
    const speechText = dictatedText + (interimText ? (dictatedText ? ' ' : '') + interimText : '');
    commentTextInput.value = dictationPrefix + speechText + dictationSuffix;
    const cursorPosition = dictationPrefix.length + speechText.length;
    commentTextInput.setSelectionRange(cursorPosition, cursorPosition);
    commentTextInput.required = !voiceClipKeyInput.value && !commentGifUrlInput.value;
    commentTextInput.dispatchEvent(new Event('input', { bubbles: true }));
    voiceCommentStatus.textContent = interimText ? 'Listening: ' + interimText : 'Voice converted to text.';
  };
  recognition.onerror = event => {
    if (speechRecognition !== recognition) return;
    if (event.error === 'no-speech') {
      voiceCommentStatus.textContent = 'No speech detected. Still listening...';
      return;
    }
    dictationActive = false;
    voiceCommentStatus.textContent = event.error === 'not-allowed' || event.error === 'service-not-allowed'
      ? 'Microphone access was not granted.'
      : 'Voice recognition stopped: ' + event.error;
  };
  recognition.onend = () => {
    if (speechRecognition !== recognition) return;
    if (dictationActive) {
      try {
        recognition.start();
        voiceCommentStatus.textContent = 'Listening...';
      } catch (error) {
        dictationActive = false;
        speechRecognition = null;
        voiceToTextButton.textContent = '🎙 Voice to text';
        voiceCommentStatus.textContent = 'Voice recognition stopped. Click to try again.';
      }
      return;
    }
    speechRecognition = null;
    voiceToTextButton.textContent = '🎙 Voice to text';
    voiceCommentStatus.textContent = dictatedText ? 'Speech added as editable text.' : 'Dictation stopped.';
  };
  try {
    recognition.start();
    voiceToTextButton.textContent = 'Stop dictation';
    voiceCommentStatus.textContent = 'Speak now. Your words will appear as text.';
  } catch (error) {
    dictationActive = false;
    speechRecognition = null;
    voiceCommentStatus.textContent = 'Unable to start voice recognition.';
  }
});
