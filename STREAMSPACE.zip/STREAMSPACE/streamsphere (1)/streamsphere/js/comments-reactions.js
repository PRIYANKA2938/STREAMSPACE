function parseReactionCount(value) {
  const match = value.trim().match(/^([\d.]+)(K|M)?$/i);
  if (!match) return 0;
  const multiplier = match[2] && match[2].toUpperCase() === 'M' ? 1000000 : match[2] ? 1000 : 1;
  return Math.round(Number(match[1]) * multiplier);
}

function initializeReactionControls(card, likes, dislikes, viewerReaction = '') {
  const bar = card.querySelector('.interaction-bar');
  if (!bar) return;
  if (bar.dataset.reactionsReady === 'true') {
    const likeButton = bar.querySelector('.reaction-btn[data-reaction="like"]');
    const dislikeButton = bar.querySelector('.reaction-btn[data-reaction="dislike"]');
    if (likeButton) likeButton.querySelector('span').textContent = Number(likes || 0).toLocaleString();
    if (dislikeButton) dislikeButton.querySelector('span').textContent = Number(dislikes || 0).toLocaleString();
    card.dataset.reaction = viewerReaction || '';
    bar.querySelectorAll('.reaction-btn').forEach(button => {
      button.classList.toggle('active', button.dataset.reaction === viewerReaction);
      button.setAttribute('aria-pressed', String(button.dataset.reaction === viewerReaction));
    });
    return;
  }
  card.dataset.reaction = viewerReaction;
  const replyButton = bar.querySelector('.reply-btn');
  bar.querySelectorAll('.action, svg').forEach(element => element.remove());
  const likeButton = createReactionButton('👍', likes, 'like');
  const dislikeButton = createReactionButton('👎', dislikes, 'dislike');
  bar.prepend(dislikeButton);
  bar.prepend(likeButton);
  if (replyButton) bar.appendChild(replyButton);
  bar.dataset.reactionsReady = 'true';
  if (viewerReaction) {
    const activeButton = bar.querySelector('.reaction-btn[data-reaction="' + viewerReaction + '"]');
    activeButton?.classList.add('active');
    activeButton?.setAttribute('aria-pressed', 'true');
  }
}

function createReactionButton(icon, count, reaction) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'reaction-btn';
  button.dataset.reaction = reaction;
  button.innerHTML = icon + ' <span>' + count.toLocaleString() + '</span>';
  button.setAttribute('aria-pressed', 'false');
  button.addEventListener('click', function() {
    const card = button.closest('.comment-card');
    if (!card) return;
    const previousReaction = card.dataset.reaction || '';
    const nextReaction = previousReaction === reaction ? '' : reaction;
    const countFor = name => Number(card.querySelector('.reaction-btn[data-reaction="' + name + '"] span').textContent.replace(/,/g, '')) || 0;
    const previousCounts = { likes: countFor('like'), dislikes: countFor('dislike') };
    const nextCounts = { ...previousCounts };
    if (previousReaction) nextCounts[previousReaction === 'like' ? 'likes' : 'dislikes'] = Math.max(0, nextCounts[previousReaction === 'like' ? 'likes' : 'dislikes'] - 1);
    if (nextReaction) nextCounts[nextReaction === 'like' ? 'likes' : 'dislikes'] += 1;

    const buttons = card.querySelectorAll('.reaction-btn');
    buttons.forEach(item => { item.disabled = true; });
    initializeReactionControls(card, nextCounts.likes, nextCounts.dislikes, nextReaction);

    requestCommentJsonp('reaction', {
      commentId: card.dataset.commentId,
      reaction: nextReaction,
      reactorId: getViewerId(),
      viewerId: getViewerId(),
      username: document.getElementById('username').value.trim() || 'Guest User'
    }).then(response => {
      if (response.status !== 'success') throw new Error(response.message || 'Unable to save comment reaction.');
      try {
        const localComments = getLocalComments();
        const localComment = localComments.find(comment => comment.commentId === card.dataset.commentId);
        if (localComment) {
          localComment.likes = nextCounts.likes;
          localComment.dislikes = nextCounts.dislikes;
          localComment.reaction = nextReaction;
          localStorage.setItem(LOCAL_COMMENTS_KEY, JSON.stringify(localComments));
        }
      } catch (error) {
        console.error('Unable to save local reaction:', error);
      }
    }).catch(error => {
      initializeReactionControls(card, previousCounts.likes, previousCounts.dislikes, previousReaction);
      console.error('Reaction error:', error);
    }).finally(() => {
      buttons.forEach(item => { item.disabled = false; });
    });
  });
  return button;
}
