const plansStatus = document.getElementById('plansStatus');

document.getElementById('plansNavLink').addEventListener('click', event => {
  event.preventDefault();
  showDestinationPage(document.getElementById('plansPage'));
});
document.getElementById('closePlans').addEventListener('click', () => {
  showMainVideoPage();
});

async function startPlanCheckout(plan) {
  if (plan === 'free') return;
  const email = (localStorage.getItem('streamsphereEmail') || '').trim();
  if (!email) {
    plansStatus.textContent = 'Add your registered email in your profile before upgrading.';
    return;
  }
  if (!window.Razorpay) {
    plansStatus.textContent = 'Razorpay checkout is unavailable. Load the Razorpay test checkout script first.';
    return;
  }
  plansStatus.textContent = 'Preparing secure checkout...';
  try {
    const orderResponse = await fetch(document.getElementById('commentForm').action, {
      method: 'POST',
      body: new URLSearchParams({ action: 'createRazorpayOrder', viewerId: getViewerId(), plan })
    });
    const order = await orderResponse.json();
    if (order.status !== 'success') throw new Error(order.message || 'Unable to create payment order.');
    const checkout = new Razorpay({
      key: order.keyId,
      amount: order.amount,
      currency: order.currency,
      name: 'StreamSphere',
      description: order.planName + ' subscription',
      order_id: order.orderId,
      prefill: { email },
      theme: { color: '#3b82f6' },
      handler: async payment => {
        plansStatus.textContent = 'Verifying payment...';
        const verifyResponse = await fetch(document.getElementById('commentForm').action, {
          method: 'POST',
          body: new URLSearchParams({
            action: 'verifyRazorpayPayment',
            viewerId: getViewerId(),
            email,
            plan,
            orderId: payment.razorpay_order_id,
            paymentId: payment.razorpay_payment_id,
            signature: payment.razorpay_signature
          })
        });
        const verification = await verifyResponse.json();
        if (verification.status !== 'success') throw new Error(verification.message || 'Payment verification failed.');
        localStorage.setItem(profilePlanKey, verification.plan);
        profilePlan.value = verification.plan;
        plansStatus.textContent = 'Payment successful. Your ' + verification.planName + ' plan is active.';
      },
      modal: { ondismiss: () => { plansStatus.textContent = 'Checkout closed.'; } }
    });
    checkout.open();
  } catch (error) {
    plansStatus.textContent = error.message || 'Unable to start checkout.';
  }
}

document.querySelectorAll('[data-plan]').forEach(button => {
  button.addEventListener('click', () => startPlanCheckout(button.dataset.plan));
});
