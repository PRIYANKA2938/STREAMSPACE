const signUpDialog = document.getElementById('signUpDialog');
const signUpForm = document.getElementById('signUpForm');
const signUpStatus = document.getElementById('signUpStatus');
const loginDialog = document.getElementById('loginDialog');
const loginForm = document.getElementById('loginForm');
const loginStatus = document.getElementById('loginStatus');

document.querySelectorAll('.password-toggle').forEach(toggle => {
  toggle.addEventListener('click', () => {
    const passwordInput = document.getElementById(toggle.dataset.passwordTarget);
    const isVisible = passwordInput.type === 'text';
    passwordInput.type = isVisible ? 'password' : 'text';
    toggle.setAttribute('aria-label', isVisible ? 'Show password' : 'Hide password');
    toggle.title = isVisible ? 'Show password' : 'Hide password';
  });
});

document.getElementById('signUpButton').addEventListener('click', () => {
  signUpStatus.textContent = '';
  if (typeof signUpDialog.showModal === 'function') signUpDialog.showModal();
  else signUpDialog.classList.add('is-open');
});
document.getElementById('cancelSignUp').addEventListener('click', () => {
  if (signUpDialog.open) signUpDialog.close();
  signUpDialog.classList.remove('is-open');
});
signUpForm.addEventListener('submit', async event => {
  event.preventDefault();
  const email = document.getElementById('signUpEmail').value.trim().toLowerCase();
  const name = document.getElementById('signUpName').value.trim().slice(0, 40);
  const password = document.getElementById('signUpPassword').value;
  const confirmPassword = document.getElementById('signUpConfirmPassword').value;
  const passwordRule = password.length >= 8 && (password.match(/\d/g) || []).length >= 2 && /[^A-Za-z0-9]/.test(password);
  if (!name) {
    signUpStatus.textContent = 'Please enter a display name.';
    return;
  }
  if (!passwordRule) {
    signUpStatus.textContent = 'Password must contain at least 8 characters, 2 numbers, and 1 special character.';
    return;
  }
  if (password !== confirmPassword) {
    signUpStatus.textContent = 'Passwords do not match.';
    return;
  }
  const submitButton = signUpForm.querySelector('[type="submit"]');
  submitButton.disabled = true;
  signUpStatus.textContent = 'Creating your account...';
  try {
    const response = await fetch(document.getElementById('commentForm').action, {
      method: 'POST',
      body: new URLSearchParams({ action: 'registerUser', name, email, password })
    });
    if (!response.ok) throw new Error('Account registration failed.');
    const result = await response.json();
    if (result.status !== 'success') throw new Error(result.message || 'Account registration failed.');
    localStorage.setItem('streamsphereEmail', email);
    localStorage.setItem('streamsphereName', name);
    document.getElementById('username').value = name;
    signUpStatus.textContent = 'Account created successfully. You can now log in.';
    signUpForm.reset();
  } catch (error) {
    signUpStatus.textContent = error.message || 'Unable to create account.';
  } finally {
    submitButton.disabled = false;
  }
});
