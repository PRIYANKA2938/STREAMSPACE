function initializeReportControl(card) {
  const bar = card.querySelector('.interaction-bar');
  if (!bar || bar.querySelector('.report-btn')) return;
  const reportButton = document.createElement('button');
  reportButton.type = 'button';
  reportButton.className = 'report-btn';
  reportButton.textContent = 'Report';
  reportButton.addEventListener('click', () => openCommentReportDialog(card, reportButton));
  bar.appendChild(reportButton);
}

let pendingCommentReport = null;
function openCommentReportDialog(card, reportButton) {
  const reportKey = 'streamsphereReported_' + card.dataset.commentId;
  if (localStorage.getItem(reportKey)) {
    reportButton.textContent = 'Reported';
    return;
  }
  pendingCommentReport = { card, reportButton };
  const dialog = document.getElementById('commentReportDialog');
  document.getElementById('commentReportReason').value = 'Inappropriate content';
  document.getElementById('commentReportDetails').value = '';
  if (typeof dialog.showModal === 'function') dialog.showModal();
  else dialog.classList.add('is-open');
}

function closeCommentReportDialog() {
  const dialog = document.getElementById('commentReportDialog');
  if (dialog.open) dialog.close();
  dialog.classList.remove('is-open');
  pendingCommentReport = null;
}

document.getElementById('cancelCommentReport').addEventListener('click', closeCommentReportDialog);
document.getElementById('commentReportForm').addEventListener('submit', async event => {
  event.preventDefault();
  if (!pendingCommentReport) return;
  const { card, reportButton } = pendingCommentReport;
  const reason = document.getElementById('commentReportReason').value;
  const details = document.getElementById('commentReportDetails').value.trim();
  reportButton.disabled = true;
  reportButton.textContent = 'Reporting...';
  try {
    const callbackName = '__streamsphereReport_' + Date.now();
    const params = new URLSearchParams({
      action: 'report',
      commentId: card.dataset.commentId,
      reporterId: getViewerId(),
      username: document.getElementById('username').value.trim() || 'Guest User',
      reason: details ? reason + ': ' + details : reason,
      callback: callbackName
    });
    await new Promise((resolve, reject) => {
      const script = document.createElement('script');
      window[callbackName] = response => {
        delete window[callbackName];
        script.remove();
        if (!response || response.status !== 'success') reject(new Error(response?.message || 'Report failed.'));
        else resolve(response);
      };
      script.onerror = () => {
        delete window[callbackName];
        script.remove();
        reject(new Error('Unable to contact the report service.'));
      };
      script.src = document.getElementById('commentForm').action + '?' + params.toString();
      document.body.appendChild(script);
    });
    localStorage.setItem('streamsphereReported_' + card.dataset.commentId, 'true');
    card.dataset.reportCount = String(Number(card.dataset.reportCount || 0) + 1);
    reportButton.textContent = 'Reported';
    closeCommentReportDialog();
  } catch (error) {
    reportButton.disabled = false;
    reportButton.textContent = 'Report';
    console.error('Report error:', error);
  }
});
