function getProfilePlan() {
  return localStorage.getItem(profilePlanKey) === 'premium' ? 'premium' : 'free';
}

function getProfileDownloads() {
  try {
    const downloads = JSON.parse(localStorage.getItem(profileDownloadsKey) || '[]');
    return Array.isArray(downloads) ? downloads : [];
  } catch (error) {
    return [];
  }
}

function renderProfileDownloads(entries = getProfileDownloads()) {
  const lists = [document.getElementById('profileDownloads'), document.getElementById('downloadsPageList')].filter(Boolean);
  const downloads = entries;
  lists.forEach(list => {
    list.innerHTML = '';
    if (!downloads.length) {
      list.innerHTML = '<p class="empty-downloads">No downloaded videos yet.</p>';
      return;
    }
    downloads.slice().reverse().forEach(download => {
      const item = document.createElement('div');
      item.className = 'download-item';
      item.innerHTML = '<div class="download-item-info"><span></span><small></small></div><small></small>';
      item.querySelector('.download-item-info span').textContent = download.title;
      item.querySelector('.download-item-info small').textContent = download.date || download.authorizedAt || '';
      item.querySelector(':scope > small').textContent = download.plan ? download.plan.toUpperCase() + ' · #' + (download.count || 1) : '';
      list.appendChild(item);
    });
  });
}

async function loadDownloadHistory() {
  try {
    const response = await fetch(document.getElementById('commentForm').action, {
      method: 'POST',
      body: new URLSearchParams({ action: 'getDownloadHistory', viewerId: getViewerId() })
    });
    const data = await response.json();
    if (data.status === 'success') renderProfileDownloads(data.history);
  } catch (error) {
    renderProfileDownloads();
  }
}

function recordProfileDownload() {
  const downloads = getProfileDownloads();
  downloads.push({ title: 'The Celestial Anomaly - Episode 4', date: new Date().toLocaleDateString() });
  localStorage.setItem(profileDownloadsKey, JSON.stringify(downloads));
}

profilePlan.disabled = true;
profilePlan.value = 'free';
async function loadProfileStatus() {
  try {
    const response = await fetch(document.getElementById('commentForm').action, {
      method: 'POST',
      body: new URLSearchParams({ action: 'getDownloadStatus', viewerId: getViewerId() })
    });
    const status = await response.json();
    if (status.status === 'success') {
      profilePlan.value = status.plan;
      localStorage.setItem(profilePlanKey, status.plan);
    }
  } catch (error) {
    console.error('Unable to load download status:', error);
  }
}
document.getElementById('profileButton').addEventListener('click', async function() {
  profileTheme.value = localStorage.getItem('streamsphereTheme') || 'auto';
  profileEmail.value = localStorage.getItem('streamsphereEmail') || '';
  profileMobile.value = localStorage.getItem('streamsphereMobile') || '';
  profileLocation.value = localStorage.getItem('streamsphereLocation') || '';
  await loadProfileStatus();
  renderProfileDownloads();
  await loadDownloadHistory();
  if (typeof profileDialog.showModal === 'function') profileDialog.showModal();
  else profileDialog.classList.add('is-open');
});
profileTheme.addEventListener('change', function() {
  if (this.value === 'auto') {
    localStorage.removeItem('streamsphereTheme');
    applyLoginTheme();
  } else {
    applyTheme(this.value);
  }
});
[profileEmail, profileMobile, profileLocation].forEach(field => {
  field.addEventListener('change', function() {
    const key = this.id === 'profileEmail' ? 'streamsphereEmail' : this.id === 'profileMobile' ? 'streamsphereMobile' : 'streamsphereLocation';
    localStorage.setItem(key, this.value.trim());
  });
});
document.getElementById('downloadsNavLink').addEventListener('click', function(event) {
  event.preventDefault();
  renderProfileDownloads();
  loadDownloadHistory();
  showDestinationPage(document.getElementById('downloadsPage'));
});
document.getElementById('closeDownloads').addEventListener('click', showMainVideoPage);
document.getElementById('closeProfile').addEventListener('click', function() {
  if (typeof profileDialog.close === 'function' && profileDialog.open) profileDialog.close();
  profileDialog.classList.remove('is-open');
});
