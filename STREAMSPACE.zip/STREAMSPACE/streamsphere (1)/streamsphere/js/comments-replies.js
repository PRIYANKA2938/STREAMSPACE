function addReplyToComment(parentCard, username, comment, timestamp, commentId = '') {
  let replies = parentCard.querySelector('.replies-list');
  if (!replies) {
    replies = document.createElement('div');
    replies.className = 'replies-list';
    parentCard.querySelector('.comment-main').appendChild(replies);
  }
  const reply = document.createElement('div');
  reply.className = 'reply-item';
  reply.dataset.commentId = commentId;
  reply.innerHTML = '<strong></strong> <span></span> <span class="timestamp dim"></span><div></div>';
  reply.querySelector('strong').textContent = username;
  reply.querySelector('span').textContent = 'replied';
  reply.querySelector('.timestamp').textContent = '\u2022 ' + formatRelativeTime(timestamp);
  reply.querySelector('.timestamp').dataset.timestamp = timestamp;
  reply.querySelector('div').textContent = comment;
  if (usernameIsCreator(username)) {
    const badge = document.createElement('span');
    badge.className = 'badge verified-creator';
    badge.textContent = 'Verified Creator';
    reply.querySelector('strong').after(badge);
  }
  replies.appendChild(reply);
  updateCommentsCount();
}

function openReplyForm(button) {
  const card = button.closest('.comment-card');
  if (!card || card.querySelector('.reply-form')) return;
  const form = document.createElement('form');
  form.className = 'reply-form';
  form.innerHTML = '<textarea required placeholder="Write a reply..."></textarea><div class="reply-form-actions"><button type="button" class="reply-cancel">Cancel</button><button type="submit" class="reply-submit">Reply</button></div>';
  card.querySelector('.comment-main').appendChild(form);
  form.querySelector('textarea').focus();
  form.querySelector('.reply-cancel').addEventListener('click', () => form.remove());
  form.addEventListener('submit', async event => {
    event.preventDefault();
    const textarea = form.querySelector('textarea');
    const replyText = textarea.value.trim();
    const moderationMessage = getModerationMessage(replyText);
    textarea.setCustomValidity('');
    if (moderationMessage) {
      textarea.setCustomValidity(moderationMessage);
      textarea.reportValidity();
      return;
    }
    const submitButton = form.querySelector('.reply-submit');
    const username = document.getElementById('username').value.trim() || 'Guest User';
    const ownerKey = getCommentOwnerKey();
    const lastPost = Number(localStorage.getItem('streamsphereLastCommentAt:' + ownerKey) || 0);
    const waitSeconds = Math.ceil((10000 - (Date.now() - lastPost)) / 1000);
    if (lastPost && waitSeconds > 0) {
      textarea.setCustomValidity('Slow mode is on. Try again in ' + waitSeconds + ' seconds.');
      textarea.reportValidity();
      return;
    }
    const timestamp = new Date().toISOString();
    const replyId = window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : String(Date.now());
    submitButton.disabled = true;
    submitButton.textContent = 'Sending...';
    try {
      const formData = new FormData(document.getElementById('commentForm'));
      formData.set('comment', replyText);
      formData.set('username', username);
      formData.set('commentId', replyId);
      formData.set('parentCommentId', card.dataset.commentId);
      formData.set('viewerId', getViewerId());
      formData.set('sessionToken', localStorage.getItem('streamsphereAuthToken') || '');
      formData.set('email', localStorage.getItem('streamsphereAuthToken') ? localStorage.getItem('streamsphereEmail') || '' : '');
      await fetch(document.getElementById('commentForm').action, { method: 'POST', body: formData, mode: 'no-cors' });
      saveLocalComment({ username, comment: replyText, commentId: replyId, parentCommentId: card.dataset.commentId, timestamp, likes: 0, dislikes: 0, ownerKey, ownerEmail: localStorage.getItem('streamsphereEmail') || '' });
      localStorage.setItem('streamsphereLastCommentAt:' + ownerKey, String(Date.now()));
      addReplyToComment(card, username, replyText, timestamp, replyId);
      const parentComment = getLocalComments().find(item => item.commentId === card.dataset.commentId);
      const parentOwnerKey = parentComment && parentComment.ownerKey || card.dataset.ownerKey || '';
      if (parentOwnerKey && parentOwnerKey !== ownerKey) {
        saveLocalNotification(parentOwnerKey, {
          commentId: card.dataset.commentId,
          replyCommentId: replyId,
          text: username + ' replied to your comment: ' + replyText.slice(0, 120),
          timestamp,
          read: false
        });
        if (parentOwnerKey === getCommentOwnerKey()) renderCommentNotifications();
      }
      form.remove();
    } catch (error) {
      submitButton.disabled = false;
      submitButton.textContent = 'Reply';
      console.error('Reply error:', error);
    }
  });
}

document.addEventListener('click', event => {
  const replyButton = event.target.closest('.reply-btn');
  if (replyButton) openReplyForm(replyButton);
});
