function getModerationMessage(comment) {
  const normalized = comment.toLowerCase().replace(/\s+/g, ' ').trim();
  const abusiveWords = ['fuck', 'shit', 'bitch', 'asshole', 'bastard', 'cunt'];
  if (abusiveWords.some(word => new RegExp('(^|[^a-z])' + word + '([^a-z]|$)', 'i').test(normalized))) {
    return 'Please remove abusive language before posting.';
  }
  if (/(https?:\/\/|www\.|[a-z0-9-]+\.(com|net|org|xyz|tk)\b)/i.test(normalized)) {
    return 'Links are not allowed in comments.';
  }
  if (/(free money|buy now|click here|subscribe now|follow me|promo code|make money)/i.test(normalized)) {
    return 'This comment looks like spam.';
  }
  const visibleCharacters = normalized.replace(/\s/g, '');
  const specialCharacters = visibleCharacters.replace(/[\p{L}\p{N}]/gu, '');
  if (visibleCharacters.length >= 4 && specialCharacters.length / visibleCharacters.length >= 0.7) {
    return 'Comments made mostly of repeated special characters are not allowed.';
  }
  if (/(.)\1{5,}/u.test(visibleCharacters) || /(\b\w+\b)(?:\s+\1){3,}/iu.test(normalized)) {
    return 'Please avoid repeated characters or repeated words.';
  }
  if (normalized.length > 5000) return 'Comments must be 5,000 characters or fewer.';
  return '';
}

function getModerationFlags(comment) {
  const message = getModerationMessage(comment);
  return message ? [message] : [];
}
