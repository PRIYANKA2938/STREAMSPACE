const subscribeButton = document.getElementById('subscribeButton');
const subscriptionKey = 'streamsphereSubscribed:streamsphere-originals';

function updateSubscribeButton() {
  const subscribed = localStorage.getItem(subscriptionKey) === 'true';
  subscribeButton.textContent = subscribed ? 'Subscribed' : 'Subscribe';
  subscribeButton.classList.toggle('subscribed', subscribed);
  subscribeButton.setAttribute('aria-pressed', String(subscribed));
}

subscribeButton.addEventListener('click', () => {
  const subscribed = localStorage.getItem(subscriptionKey) === 'true';
  localStorage.setItem(subscriptionKey, String(!subscribed));
  updateSubscribeButton();
});
updateSubscribeButton();
