const savedTheme = localStorage.getItem('streamsphereTheme');
if (savedTheme === 'light' || savedTheme === 'dark') applyTheme(savedTheme, false);
else applyLoginTheme();
updatePersonalizedExperience();
setInterval(updatePersonalizedExperience, 60000);
