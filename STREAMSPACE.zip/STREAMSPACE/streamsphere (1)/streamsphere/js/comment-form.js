document.getElementById('commentForm').addEventListener('reset', () => {
  if (voiceRecording) stopVoiceRecording(true);
  if (speechRecognition) {
    dictationActive = false;
    speechRecognition.abort();
    speechRecognition = null;
    voiceToTextButton.textContent = '🎙 Voice to text';
  }
  if (document.getElementById('commentForm').dataset.keepVoiceClip !== 'true') removeVoiceClip(voiceClipKeyInput.value);
  document.getElementById('commentForm').dataset.keepVoiceClip = 'false';
  voiceClipKeyInput.value = '';
  commentGifUrlInput.value = '';
  document.getElementById('commentContainsSpoiler').value = 'false';
  document.getElementById('commentSpoilerToggle').checked = false;
  commentTextInput.required = true;
  voiceCommentPreview.pause();
  voiceCommentPreview.removeAttribute('src');
  voiceCommentPreview.hidden = true;
  voiceCommentStatus.textContent = '';
  document.getElementById('commentCharacterCount').textContent = '0 / 5,000';
});

// Form submission handler with proper CORS handling
document.getElementById('commentForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  
  const submitBtn = document.getElementById('submitBtn');
  const statusMsg = document.getElementById('statusMsg');
  const commentText = document.getElementById('commentText');
  const username = document.getElementById('username').value.trim() || 'Guest User';
  const voiceClipKey = voiceClipKeyInput.value;
  const gifUrl = commentGifUrlInput.value;
  const containsSpoiler = document.getElementById('commentSpoilerToggle').checked;
  const comment = commentText.value.trim() || (voiceClipKey ? '[Voice comment]' : gifUrl ? '[GIF]' : '');
  const showLocation = document.getElementById('showLocationToggle').checked;
  const location = showLocation ? (localStorage.getItem('streamsphereLocation') || '') : '';
  const commentId = window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : String(Date.now());

  let moderationFlags = getModerationFlags(comment);
  if (comment.length <= 5000) {
    try {
      const serverModeration = await requestCommentJsonp('checkComment', { comment });
      if (serverModeration.allowed === false && serverModeration.message && !moderationFlags.includes(serverModeration.message)) {
        moderationFlags = [...moderationFlags, serverModeration.message];
      }
    } catch (error) {
      console.warn('Server moderation preflight unavailable:', error);
    }
  }
  const hasAttachment = !!voiceClipKey || !!gifUrl;
  const lastPost = Number(localStorage.getItem('streamsphereLastCommentAt:' + getCommentOwnerKey()) || 0);
  const secondsUntilNextPost = Math.ceil((10000 - (Date.now() - lastPost)) / 1000);
  if (lastPost && secondsUntilNextPost > 0) {
    statusMsg.className = 'form-status error';
    statusMsg.textContent = 'Slow mode is on. Try again in ' + secondsUntilNextPost + ' seconds.';
    statusMsg.style.display = 'block';
    return;
  }
  if (!comment || comment.length > 5000) {
    statusMsg.className = 'form-status error';
    statusMsg.textContent = '✗ ' + (!comment ? 'Add text, a GIF, or a voice recording.' : 'Comments must be 5,000 characters or fewer.');
    statusMsg.style.display = 'block';
    return;
  }
  
  // Disable submit button
  submitBtn.disabled = true;
  submitBtn.textContent = 'Submitting...';
  
  // Collect form data
  const formData = new FormData(this);
  formData.set('action', moderationFlags.length ? 'submitCommentForReview' : '');
  formData.set('commentId', commentId);
  formData.set('location', location);
  formData.set('showLocation', String(showLocation));
  formData.set('email', localStorage.getItem('streamsphereAuthToken') ? localStorage.getItem('streamsphereEmail') || '' : '');
  formData.set('viewerId', getViewerId());
  formData.set('sessionToken', localStorage.getItem('streamsphereAuthToken') || '');
  formData.set('gifUrl', gifUrl);
  formData.set('voiceClipKey', voiceClipKey);
  formData.set('spoiler', String(containsSpoiler));
  
  try {
    // Send to Google Apps Script
    const response = await fetch(this.action, {
      method: 'POST',
      body: formData,
      mode: 'no-cors'
    });
    
    // no-cors returns an opaque response, so this confirms only that the request was sent.
    statusMsg.className = moderationFlags.length ? 'form-status error' : 'form-status success';
    statusMsg.textContent = moderationFlags.length ? 'This comment was held for moderator review: ' + moderationFlags.join(', ') : 'Comment sent. It may take a moment to appear.';
    statusMsg.style.display = 'block';

    const timestamp = new Date().toISOString();
    const savedComment = { username, comment, commentId, timestamp, location, showLocation, likes: 0, dislikes: 0, ownerKey: getCommentOwnerKey(), ownerEmail: localStorage.getItem('streamsphereEmail') || '', moderationStatus: moderationFlags.length ? 'Pending Review' : 'Approved', moderationReason: moderationFlags.join(', '), gifUrl, voiceClipKey, spoiler: containsSpoiler, language: document.getElementById('language').value || 'English' };
    saveLocalComment(savedComment);
    addCommentToDashboard(username, comment, !moderationFlags.length, commentId, 0, 0, '', timestamp, location, savedComment);
    localStorage.setItem('streamsphereLastCommentAt:' + getCommentOwnerKey(), String(Date.now()));
    
    // Clear form
    this.dataset.keepVoiceClip = 'true';
    this.reset();
    commentText.focus();
    
    // Hide success message after 4 seconds
    setTimeout(() => {
      statusMsg.style.display = 'none';
    }, 4000);
    
  } catch (error) {
    statusMsg.className = 'form-status error';
    statusMsg.textContent = '✗ Network error. Please try again.';
    statusMsg.style.display = 'block';
    console.error('Form submission error:', error);
  } finally {
    // Re-enable submit button
    submitBtn.disabled = false;
    submitBtn.textContent = 'Comment';
  }
});
