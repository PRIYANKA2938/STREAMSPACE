async function playNextVideo() {
  const nextItem = document.querySelector('.reco-item');
  if (nextItem) {
    loadRecommendedVideo(nextItem);
  }
}

const recommendedVideoData = [
  { videoId: 'celestial-anomaly-ep5', title: 'The Celestial Anomaly - Episode 5: Descent', duration: '45:12', source: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4' },
  { videoId: 'neon-horizons-finale', title: 'Neon Horizons - Season Finale', duration: '52:08', source: 'https://media.w3.org/2010/05/sintel/trailer.mp4' },
  { videoId: 'behind-the-code-sentience', title: 'Behind the Code: Artificial Sentience', duration: '28:45', source: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4' },
  { videoId: 'starfall-origins-first-contact', title: 'Starfall Origins: First Contact', duration: '39:20', source: 'https://media.w3.org/2010/05/sintel/trailer.mp4' },
  { videoId: 'signal-lost-mystery', title: 'Signal Lost: The Deep Space Mystery', duration: '31:06', source: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4' },
  { videoId: 'archive-door-timeline', title: 'The Archive Door: A Timeline Unlocked', duration: '48:15', source: 'https://media.w3.org/2010/05/sintel/trailer.mp4' }
];

function loadRecommendedVideo(card) {
  const index = Array.from(document.querySelectorAll('.reco-item')).indexOf(card);
  const video = recommendedVideoData[index];
  if (!video) return;
  const source = demoVideo.querySelector('source');
  document.querySelector('.video-title').textContent = video.title;
  document.querySelector('.video-stats').textContent = 'Recommended for you · ' + video.duration;
  document.querySelector('.video-player').dataset.downloadUrl = video.source;
  document.getElementById('videoId').value = video.videoId;
  loadVideoReactionState();
  source.src = video.source;
  demoVideo.load();
  demoVideo.play().catch(error => console.error('Unable to autoplay selected video:', error));
  videoPlayer.classList.add('is-loading');
  document.querySelectorAll('.reco-item').forEach(item => item.classList.remove('is-next-selected'));
  card.classList.add('is-next-selected');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

document.querySelectorAll('.reco-item').forEach(card => {
  card.addEventListener('click', () => loadRecommendedVideo(card));
});
