const LOCAL_COMMENTS_KEY = 'streamsphereLocalComments';
const VIEWER_ID_KEY = 'streamsphereViewerId';

function getViewerId() {
  let viewerId = localStorage.getItem(VIEWER_ID_KEY);
  if (!viewerId) {
    viewerId = window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : String(Date.now()) + Math.random();
    localStorage.setItem(VIEWER_ID_KEY, viewerId);
  }
  return viewerId;
}

function getCommentOwnerKey() {
  const email = localStorage.getItem('streamsphereEmail') || '';
  const sessionToken = localStorage.getItem('streamsphereAuthToken') || '';
  return email && sessionToken ? 'email:' + email.trim().toLowerCase() : 'viewer:' + getViewerId();
}
